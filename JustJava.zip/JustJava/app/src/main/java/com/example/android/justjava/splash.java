package com.example.android.justjava;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class splash extends AppCompatActivity {
    Spinner spinner;

    int quantity=0;
    int price=0;
    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        spinner=(Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter= ArrayAdapter.createFromResource(this,
                R.array.types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spinner.setAdapter(adapter);
        //spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           /* @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getBaseContext(),adapterView.getItemAtPosition(i)+" selected",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/
        toolbar=(Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("CRATE cafe");
        //toolbar.setTitleTextColor( );
        toolbar.setSubtitle("Taste as good as it smells");
        //toolbar.setSubtitleTextColor(@color);
       // toolbar.setLogo(R.drawable.qaz);


    }
    public void increment(View view) {

        quantity=quantity+1;
        displayQuantity(quantity);
    }
    public void decrement(View view) {

        if(quantity>=1)

            quantity=quantity-1;
        displayQuantity(quantity);
        if(quantity==0) {
            Toast.makeText(getApplicationContext(), "cannot have less than 1 coffee", Toast.LENGTH_SHORT).show();
        }
    }
    public void submitOrder(View view) {


        CheckBox creambox=(CheckBox) findViewById(R.id.creambox);
        boolean hasWhippedCream =  creambox.isChecked();
        CheckBox chocolate =(CheckBox) findViewById(R.id.chocolate);
        boolean hasChocolate=  chocolate.isChecked();
        EditText textView=(EditText) findViewById(R.id.album_description_view) ;
        String name=textView.getText().toString();
        int price = calculatePrice(hasWhippedCream,hasChocolate);

        String data=createOrderSummary(price,hasWhippedCream,hasChocolate,name);




        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this

        intent.putExtra(Intent.EXTRA_SUBJECT,"coffee order for "+name);
        intent.putExtra(Intent.EXTRA_TEXT,data);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    /**
     * Calculates the price of the order.
     *
     * @param quantity is the number of cups of coffee ordered
     */
    public int calculatePrice(boolean addWhippedCream,boolean addChocolate) {

        int baseprice=20;
        if(addWhippedCream)
        {
            baseprice=baseprice+10;
        }
        if(addChocolate)
        {
            baseprice=baseprice+20;
        }
        return  quantity*baseprice;
    }

    public String createOrderSummary(int price,boolean addWhippedCream,boolean addChocolate,String name)
    {





        String data=" Name:"+name+"\n Add Whipped Cream?"+addWhippedCream+"\n Add Chocolate?"+addChocolate+"\n Quantity:"+quantity+"\n Total:"+price;
        return data;


    }

    /**
     * This method displays the given quantity value on the screen.
     */
    private void displayQuantity(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }
    /**
     * This method displays the given price on the screen.
     */
    /**
     * This method displays the given text on the screen.
     */
}
